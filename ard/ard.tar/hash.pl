
use Data::Dumper;



my %test =  ( 'key1', 'value1', 'key2', 'value2', 'key3', 'value3' );

print "hello \n";

#$test{'hell'} = 'poop';

print Dumper (%test);



